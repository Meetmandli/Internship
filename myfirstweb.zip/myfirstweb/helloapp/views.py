
from django.shortcuts import render
from django.http import HttpResponse
from django.views.generic import ListView
from .models import Student

def homepageview(request):
    return render(request,'home.html')

def aboutpageview(request):
    return render(request,'about.html')


def contactpageview(request):
    return render(request,'contact.html')


def myform(request):
    return render(request,'form.html')

def process(request):
    print("welcome")
    print(request.method)
    print(request.POST)
    a = int(request.POST['txt1'])
    b = int(request.POST['txt2'])
    c = a + b
    
    return render(request,'ans.html',{'mysum':c})

class studentlist(ListView):
    model = Student
    template_name = 'slist.html'

