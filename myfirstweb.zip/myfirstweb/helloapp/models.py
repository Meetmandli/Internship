from django.db import models

# Create your models here.
class Student(models.Model):
    First_Name = models.CharField(max_length=30)
    Last_Name = models.CharField(max_length=30)
    Male = models.BooleanField(default=False)
    Female = models.BooleanField(default=False)
    Fees = models.IntegerField()
    def __str__(self) :
        return self.First_Name

class Employee(models.Model):
    First_Name = models.CharField(max_length=30)
    Last_Name = models.CharField(max_length=30)
    Male = models.BooleanField(default=False)
    Female = models.BooleanField(default=False)
    Salary = models.IntegerField()


    def __str__(self) :
        return self.First_Name